const chartInstances={};
export function drawChart(id,config){const canvas=document.getElementById(id);if(!canvas||!window.Chart)return;if(chartInstances[id])chartInstances[id].destroy();chartInstances[id]=new Chart(canvas,{...config,options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{usePointStyle:true,boxWidth:7,font:{family:"DM Sans",size:10},color:"#718096"}},...config.options?.plugins},...config.options}});}
export function clearChart(id){if(chartInstances[id]){chartInstances[id].destroy();delete chartInstances[id];}}

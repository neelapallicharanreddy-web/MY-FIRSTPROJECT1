export async function loadDatabase(){
 const response=await fetch("./data/students.json");
 if(!response.ok)throw new Error("Could not load data/students.json. Run this project using Live Server.");
 const db=await response.json(); validateDatabase(db); return db;
}
export const gradePoints={O:10,"A+":9,A:8,"B+":7,B:6,C:5,F:0};
export function validateDatabase(db){
 if(!db||!Array.isArray(db.students)||db.students.length<100)throw new Error("Dataset must contain at least 100 student records.");
 const seen=new Set();
 for(const s of db.students){if(!s.hallTicket||seen.has(s.hallTicket.toUpperCase()))throw new Error("Missing or duplicate hall ticket found in sample data.");seen.add(s.hallTicket.toUpperCase());for(const sem of s.semesters||[]){for(const sub of sem.subjects||[]){if(!(sub.credits>0)||!(sub.total>=0&&sub.total<=100)||!(sub.internal>=0&&sub.external>=0)||!Object.hasOwn(gradePoints,sub.grade))throw new Error(`Invalid marks/grade data for ${s.hallTicket} in ${sub.subject}.`);}}}
 return true;
}
export function semesterGpa(semester){const credits=semester.subjects.reduce((s,x)=>s+x.credits,0);const weighted=semester.subjects.reduce((s,x)=>s+x.credits*(gradePoints[x.grade]??0),0);return credits?weighted/credits:0;}
export function studentCgpa(student){const all=student.semesters.flatMap(s=>s.subjects);const credits=all.reduce((s,x)=>s+x.credits,0);return credits?all.reduce((s,x)=>s+x.credits*(gradePoints[x.grade]??0),0)/credits:0;}
export function findStudent(db,ticket){return db.students.find(s=>s.hallTicket.toLowerCase()===String(ticket||"").trim().toLowerCase());}
export function studentsFor(db,batch="all",branch="all"){return db.students.filter(s=>(batch==="all"||s.batch===batch)&&(branch==="all"||s.branch===branch));}
export function semesterOf(student,sem){return student.semesters.find(s=>s.semester===Number(sem));}
export function latestSemester(db,batch="all",sem=4,branch="all"){return studentsFor(db,batch,branch).map(student=>({student,semester:semesterOf(student,sem)})).filter(x=>x.semester);}
export function subjectStats(records,passMark=40){const subjects=records[0]?.semester.subjects||[];return subjects.map((subject,index)=>{let pass=0;records.forEach(r=>{const sub=r.semester.subjects.find(x=>x.code===subject.code)||r.semester.subjects[index];if(sub&&sub.total>=passMark&&sub.grade!=="F")pass++;});const count=records.length;return {code:subject.code,name:subject.subject,pass,fail:count-pass,count,passRate:count?pass/count*100:0,failRate:count?(count-pass)/count*100:0};});}
export function latestCgpaDistribution(students){const bins=[{label:"Below 5",min:0,max:5},{label:"5–6",min:5,max:6},{label:"6–7",min:6,max:7},{label:"7–8",min:7,max:8},{label:"8–9",min:8,max:9},{label:"9–10",min:9,max:10.01}];return bins.map(b=>({label:b.label,count:students.filter(s=>{const c=studentCgpa(s);return c>=b.min&&c<b.max;}).length}));}
export function studentRank(db,student,sem){const peers=latestSemester(db,student.batch,sem,student.branch).map(x=>({ticket:x.student.hallTicket,sgpa:semesterGpa(x.semester)})).sort((a,b)=>b.sgpa-a.sgpa);const rank=peers.findIndex(x=>x.ticket===student.hallTicket)+1;return {rank,total:peers.length,percentile:peers.length?((peers.length-rank)/peers.length*100):0};}

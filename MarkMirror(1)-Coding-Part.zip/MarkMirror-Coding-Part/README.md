# MarkMirror: ResultRadar Rush

A responsive student result lookup and academic analytics dashboard built with HTML5, CSS3, Vanilla JavaScript ES modules, Chart.js, and a JSON sample dataset.

## Run locally

1. Open this folder in Visual Studio Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` and choose **Open with Live Server**.
4. Use demo hall ticket **22CSE104** and select Semester 4. The demo record is designed to calculate an SGPA of **8.85**.

Do not open `index.html` directly using `file://`, because the app fetches `data/students.json`.

## Features mapped to the problem brief

### Must-have requirements

- Hall ticket result lookup with semester selection.
- Credit-weighted SGPA and CGPA calculations.
- Subject-wise pass-rate bar chart and combined pass/fail chart.
- Top 10 leaderboard with top 5 featured cards; filters for batch, branch, and semester.
- CGPA distribution histogram.
- Printable A4-style marksheet using browser Print / Save as PDF.

### Stretch requirements

- Semester-wise SGPA trend chart.
- Re-evaluation fee estimator.
- Subject difficulty index based on failure rate.
- Graduating batch comparison.

### Additional enhancements

- Branch and batch filters on dashboard analytics.
- Export subject analytics and leaderboard to CSV.
- Student branch/batch rank and percentile insight on the marksheet.
- Recent hall-ticket searches shown as quick-access chips and saved locally in browser storage.
- Copyable result summary.
- Recent hall-ticket searches saved locally in browser storage.
- Dataset validation at application startup (record count, unique hall tickets, valid marks, credits, and grade labels).
- Responsive layout for desktop, tablet, and mobile.

## Dataset and demo assumptions

`data/students.json` contains 100 sample records, multiple graduating batches, three branches, four semesters, and six subjects. The project brief does not provide the institution's complete grade mapping, pass threshold, exact subject credits, or re-evaluation fee. Therefore, these values are demonstration assumptions and can be edited in the JSON/configuration:

- Grade points: O=10, A+=9, A=8, B+=7, B=6, C=5, F=0.
- Pass mark: 40/100.
- Re-evaluation estimate: ₹500 per subject.
- Credits: Math 4, DBMS 4, OS 3, Computer Networks 3, Software Engineering 3, AI Lab 3.

Semester 4 sample marks are tuned so Operating Systems has a 68% pass rate, matching the sample demonstration in the brief. The sample record `22CSE104` calculates to SGPA 8.85 using the weighted-credit formula.

**Important:** This is a front-end mini-project demonstration, not an authenticated university portal. Do not present generated sample records or marksheets as official student results. Replace the assumptions with verified institutional rules before real deployment.

## Project structure

```text
MarkMirror-Coding-Part/
├── index.html
├── package.json
├── README.md
├── RUN-INSTRUCTIONS.txt
├── css/
│   ├── style.css
│   ├── dashboard.css
│   └── responsive.css
├── js/
│   ├── app.js
│   ├── data.js
│   ├── calculations.js
│   ├── charts.js
│   ├── results.js
│   ├── analytics.js
│   ├── leaderboard.js
│   ├── history.js
│   ├── reevaluation.js
│   └── comparison.js
├── data/
│   └── students.json
└── tests/
    └── validate-data.mjs
```

## Data validation test

With Node.js installed, run:

```bash
npm run test:data
```

The test validates the 100-record dataset, demo SGPA 8.85, and Semester 4 Operating Systems pass rate 68%.

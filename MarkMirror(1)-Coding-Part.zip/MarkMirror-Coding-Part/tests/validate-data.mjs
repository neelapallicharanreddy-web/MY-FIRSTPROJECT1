import fs from 'node:fs';
import { semesterGpa, studentCgpa, validateDatabase } from '../js/data.js';

const db = JSON.parse(fs.readFileSync(new URL('../data/students.json', import.meta.url), 'utf8'));
validateDatabase(db);
const demo = db.students.find(s => s.hallTicket === '22CSE104');
if (!demo) throw new Error('Required demo hall ticket 22CSE104 is missing.');
const demoSgpa = semesterGpa(demo.semesters.find(s => s.semester === 4));
if (demoSgpa.toFixed(2) !== '8.85') throw new Error(`Expected demo SGPA 8.85, got ${demoSgpa.toFixed(2)}.`);
const sem4 = db.students.map(s => s.semesters.find(x => x.semester === 4)).filter(Boolean);
const osIndex = sem4[0].subjects.findIndex(s => s.code === 'OPS203');
const osPass = sem4.filter(s => s.subjects[osIndex].total >= db.passMark && s.subjects[osIndex].grade !== 'F').length;
const osRate = osPass / sem4.length * 100;
if (osRate.toFixed(0) !== '68') throw new Error(`Expected OS pass rate 68%, got ${osRate.toFixed(1)}%.`);
console.log(`PASS: ${db.students.length} records validated.`);
console.log(`PASS: 22CSE104 Semester 4 SGPA = ${demoSgpa.toFixed(2)}; CGPA = ${studentCgpa(demo).toFixed(2)}.`);
console.log(`PASS: Operating Systems Semester 4 pass rate = ${osRate.toFixed(1)}%.`);
